<div id="search_tweets">
  <h2>Search Tweets</h2>


<form action="" method="POST">
    <div>
      <label for="q">Search Term</label>
      <input type="text" name="q"></input>
    
      <br />
      <input type="submit" value="Submit" />
    </div>
  </form>


<?php

if (!empty($_POST['q'])) {
   
      $search_word = $_POST['q'];
      $homepage = file_get_contents('http://bealifechamp.com/tmhOAuthExamples-master/?q='.$search_word.'&e=search_tweets');
      echo $homepage;
    } else {

      echo 'no result';
    }
    
?>

  

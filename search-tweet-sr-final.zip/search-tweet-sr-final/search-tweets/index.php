<?php
require 'tmhOAuthExample.php';
$tmhOAuth = new tmhOAuthExample();
define('DEMO_ROOT', __DIR__.DIRECTORY_SEPARATOR.'web');
session_start();
function available_demos($dir) {
  $demos = array();
  $dh = opendir($dir);
  while (($name = readdir($dh)) !== false) {
    if (!is_dir("${dir}/${name}") && !in_array($name, array('.', '..', '.git')) && stripos($name, '.php')) {
      $title = str_ireplace('.php', '', $name);
      $demos[$title] = "${dir}/${name}";
    }
  }
  return $demos;
}
function current_demo($demos) {
  if (isset($_GET['e']) && in_array($_GET['e'], array_keys($demos)))
    return $_GET['e'];
  return null;
}
function page_title($demo) {
  $title = 'tmhOAuth Examples';
  if (!is_null($demo))
    $title .= ': ' . $demo;
  echo $title;
}
function demo_a_tag($name) {
  echo "<a href=\"?e=${name}\">${name}</a>";
}
function get_media($ismedia) {
    if (is_array($ismedia)) {
      foreach ( $ismedia as $getmedia ) {
        echo $getmedia->media_url;
      }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Search Tweets API</title>
  <!-- Bootstrap core CSS -->
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <link href="../css/style.css" rel="stylesheet">
  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body id="searchTweet">
<nav class="navbar navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="/">Search Tweet Api</a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Dashboard</a></li>
        <li><a href="#">Settings</a></li>
        <li role="presentation" class="dropdown"> <a href="#" class="dropdown-toggle" id="drop4" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Profile <span class="caret"></span> </a>
        <ul class="dropdown-menu" id="menu1" aria-labelledby="drop4">
          <li><a href="../index.php">Logout</a></li>
        </ul>
      </li>
      <li><a href="#">Help</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container tweet-main-container">
  <div id="search_tweets">
  <div class="row header-tweet">
    <div col-md-12>
      <h2>Search Tweets</h2>
        <form action="" method="GET">
        <div>
          <div class="form-group">
            <label for="q">Search Term</label>
          </div>
          <input type="text" name="q" class="form-control"></input>
          <div class="form-group">
            <input type="hidden" name="e" value="search_tweets"></input>
          </div>
          <div class="form-group">
            <input type="submit" value="Submit" class="btn btn-md btn-primary" />
          <div class="form-group">
        </div>
      </form>
    </div>
  </div>
  <div class="row-tweet-wrapper">
    <div class="grid">
      <div class="grid-sizer"></div>
    <?php
    if (!empty($_GET['q'])) {
    $code = $tmhOAuth->apponly_request(array(
      'url' => $tmhOAuth->url('1.1/search/tweets'),
      'params' => array(
        'q' => $_GET['q']
      )
    ));
    if ($code == 200) :
    $data = json_decode($tmhOAuth->response['response']);
    foreach ( $data as $get_data ) {
      foreach ( $get_data as $new_data ) {
        ?>
        <div class="grid-item">
          <div class="tweet ">
          <h3 class="title"><?php echo $new_data->user->name ? $new_data->user->name : ''?></h3>
          <img src="<?php echo $new_data->user->profile_image_url; ?>" class="profile">
          <p class="text"><?php echo $new_data->text;?> </p>
          <p class="source"><?php echo $new_data->source; ?> </p>
          <p><span><i class="far fa-heart"></i></span> <span><i class="far fa-comment"></i></span></p>
          <img src="<?php get_media($new_data->entities->media); ?>" class="img-responsive">
          </div>
        </div>
        <!-- <pre><?php //print_r($new_data);?></pre> -->
        <?php
      }
    }
    ?>
    </div><!-- grid -->
  </div><!-- row -->
  <?php else : ?>
  <h3>Something went wrong</h3>
  <p><?php echo $tmhOAuth->response['error'] ?></p>
  <?php endif; ?>
  </div>
  <?php } else { ?>
  <?php } ?>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../js/isotope.pkgd.min.js"></script>
<script src="../js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript">
  $(function(){
    var $container = $('.grid');
    $container.imagesLoaded( function() {
        $container.isotope({
            itemSelector: '.grid-item',
            columnWidth: '.grid-sizer',
            gutter: 10,
            percentPosition: true,
            transitionDuration: 200
        });
        $container.isotope( 'shuffle', function() {});
    });  
});
</script>
</body>
</html>
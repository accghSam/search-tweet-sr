<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="#">
    <meta name="author" content="Sam">
    <link rel="icon" href="/">
    <title>Twitter Search Login</title>
    <!-- Bootstrap core CSS -->
    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="./css/style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>
    <body>
    <div class="container">
<div class="form-body">
  <!-- Nav tabs -->
  <ul id="loginTab" class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active">
        <a href="#login" aria-controls="login" role="tab" data-toggle="tab">Login</a>
    </li>
    <li role="presentation">
        <a href="#signup" aria-controls="signup" role="tab" data-toggle="tab">Sign Up</a>
    </li>
  </ul>
  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="login">
        <form class="form-signin">
            <h2 class="form-signin-heading">Please Login</h2>
            <div class="form-group">
                <label for="inputEmail" class="sr-only">Email address</label>
                <input type="email" id="inputEmail" class="form-control signin-form-control" placeholder="Email address" required="" autofocus="">
            </div>
            <div class="form-group">
                <label for="inputPassword" class="sr-only">Password</label>
                <input type="password" id="inputPassword" class="form-control signin-form-control" placeholder="Password" required="">
            </div>
            <div class="form-group">
                <div class="checkbox">
                <label>
                <input type="checkbox" value="remember-me"> Remember me
                </label>
            </div>
            </div>
            <a href="./search-tweets/" class="btn btn-md btn-primary" type="submit">Login</a>
            <a href="#">Lost your password?</a>
      </form>
    </div>
    <div role="tabpanel" class="tab-pane" id="signup">
        <form class="form-signup">
          <div class="form-group">
            <label for="Name">Name</label>
            <input type="text" class="form-control" id="name" placeholder="Name">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
          </div>
          <button type="submit" class="btn btn-md btn-primary">Submit</button>
        </form>
    </div>
  </div>
</div>
    </div> <!-- /container -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        $(function(){
            $('#loginTab a').click(function (e) {
              e.preventDefault()
              $(this).tab('show')
            });
        });
    </script>
    </body>
</html>